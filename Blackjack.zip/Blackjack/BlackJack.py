# Créé par nsi, le 28/09/2023 en Python 3.7

# ------------------------ #
from cartes import *       #
from random import shuffle #
from jeu_de_carte import * #
from personne import *     #
from dealer import *       #
from sys import *          #
# ------------------------ #

## Notes au préalable : il est conseillé de jouer avec une grande interface de console afin de pouvoir examiner toutes les informations librement. ##
## Aussi le système de mises a été simplifié (rembourser en cas d'égalité, *1.5 si plus grand, *2 si dépasse 21, *3 BlackJack)
## Obtenir un 21 avec un Hit compte comme un BlackJack (/!\ ne le fais pas remarquer au Joueur qui peut Bust juste après)

## Voc. : Hit(pioche) ; Stand(Valider la main) ; Deal (distribution des cartes) ; BlackJack (ici --> 21 dans tous les cas) ; Bust (dépasser 21) ; SURRENDER (abandon)

## Le Dealer obéit à la règle du 17 Soft c'est-à-dire qu'il continue de piocher jusqu'à attiendre ou dépasser 17.

# ----------- REJOUER (POUR RELANCER UNE PARTIE) ----------- #

def rejouer():
    rep = str(input("Veux-tu rejouer ? [O]ui ou [N]on\n")).lower() # Forme de question que j'ai vu sur un jeu vidéo et qui m'a plu :)
    if rep == "o":
        monJeu.reinitialiser_paquet()
        monJeu.melanger_paquet() # Nouveau paquet mélangé
        joueur.reinitialiser_joueur() # Main et points réinitialisés
        dealer.reinitialiser_joueur() # Main et points réinitialisés
        blackjack_jeu() # Relancement du jeu
    else :
        print ("Aurevoir !\n") # Il ne se passe rien

# ----------- VERIFICATION BLACKJACK (VERIFICATION OBLIGATOIRE APRES LE DEAL) ----------- #

def blackjack_verif(d, j, mise):
    if j == 21 and d == 21 : # Egalité des BlackJack
        print("----------------------------------\n")
        print(joueur)
        print(dealer)
        print ("INCROYABLE ! Vous avez tous les deux un BlackJack 80 ! Tu récupères donc ta mise. ;) \n")
        joueur.jetons += mise
        rejouer()

    elif j == 21: # BlackJack du Joueur (après avoir vérifié une EGALITE ! --> Victoire assurée)
        print("----------------------------------\n")
        print(joueur)
        print(dealer)
        print ("Bravo ! C'est Blackjack ! Tu es assuré d'avoir gagné :D !\n")
        joueur.jetons += mise*3
        rejouer()

    elif d == 21: # BlackJack du Dealer (après avoir vérifié une EGALITE ! --> Défaite assurée)
        print("----------------------------------\n")
        print(joueur)
        print(dealer)
        print ("Désolé, mais le Dealer a un Blackjack... Tu as perdu :C !\n")
        rejouer()

# ----------- CALCUL DES SCORES (UTILE DE LE DISSOCIER DU JEU PRINCIPAL)----------- #

def score(d, j, mise):
    if j == 21 and d == 21 : # Egalité des BlackJack
        print ("INCROYABLE ! Vous avez tous les deux un BlackJack 80 ! Tu récupères donc ta mise. ;) \n")
        joueur.jetons += mise

    elif j == 21: # BlackJack du Joueur
        print ("Bravo ! C'est un BlackJack :D ! Tu as GAGNE !\n")
        joueur.jetons += mise*3

    elif d == 21: # BlackJack du Dealer
        print ("Désolé, mais le Dealer a un Blackjack... Tu as perdu :C !.\n")

    elif j > 21: # Bust du Joueur
        print ('Tu as dépassé 21 ! Tu as PERDU :C !\n')

    elif d > 21: # Bust du Dealer
        print ('Le Dealer a dépassé 21, tu as gagné :D!\n')
        joueur.jetons += mise*2

    elif j < d : # Plus gros score = Dealer
        print ("Désolé, le Dealer a un plus gros score que toi :C. Tu as PERDU !\n")

    elif j > d: # Plus gros score = Joueur
        print ("Bravo ! Tu as un plus gros score que le Dealer :D. Tu as GAGNE !\n")
        joueur.jetons += mise*1.5

    elif j == d: # Egalité des scores
        print ("SUPERBE ! Il y a égalité, je te redonne donc ta mise.\n")
        joueur.jetons += mise

# ------ LA SOLUTION ULTIME CONTRE LA PAUVRETE !!! ------ #

# J'ai ajouté cette fonctionalité si on n'a plus d'argent parce que c'était drôle.

def soluce_ultime() :
    print("----------------------------------\n")
    print("*Diable apparaît* Hé hé hé :D ! Tu n'as plus d'argent... Veux-tu parier autre chose ?\n")
    rep = str(input("[O]ui/[N]on, les personnes et animaux ne sont pas autorisés, mais les voitures, maisons, portables, montres et autres... ;)\n")).lower()
    if rep == "o" :
        print("----------------------------------\n")
        print("Niark ! Niark ! Niark ! Tu es vraiment stup... intelligent pour avoir fais ce choix. Tiens, voilà 100 jetons. *Diable disparaît*\n")
        joueur.jetons = 100
    else :
        print("----------------------------------\n")
        print("Oh... Je vois... Amuses-toi bien dans la pauvreté :/ *Diable disparaît*\n")

# ------ LE JEU !!! (BLACKJACK AVEC MISES) ------ #

def blackjack_jeu() :
    choix = 0

    if joueur.jetons == 0 :
        soluce_ultime()

    if joueur.jetons == 0 :
        print("----------------------------------\n")
        print("Désolé, vous n'avez plus de jetons. Revenez plus tard.\n")
        exit() # Je n'ai pas trouvé d'autres moyens que exit() pour sortir rapidement

    print("----------------------------------\n")
    mise = int(input("Combien veux-tu miser ? Tu détiens actuellement " + str(joueur.jetons) + " jetons.")) # Système de mise avec relancement si trop haute
    while mise > joueur.jetons :
        joueur.miser(mise)
        mise = int(input("Combien veux-tu miser ?"))
    joueur.miser(mise)

    print("----------------------------------\n")
    joueur.donner_carte(monJeu.tirer_carte()) # Deal du Joueur
    joueur.donner_carte(monJeu.tirer_carte())

    print("----------------------------------\n")
    print(dealer.donner_carte(monJeu.tirer_carte())  + " ainsi qu'une autre carte.\n") # Deal du Dealer
    dealer.donner_carte(monJeu.tirer_carte())

    print("----------------------------------\n")
    print("Voici votre main :\n ") # Présentation au Joueur de sa main
    joueur.calculer_points()
    print(joueur)

    blackjack_verif(dealer.points, joueur.points, mise) # Vérification d'un BlackJack

    stop=False

    while not stop:

        choix = int(input("Que veux-tu faire :\n 1.Tirer une carte supplémentaire\n 2. Valider ta main\n 3. Arrêter de jouer\n ")) # Choix d'un HIT, STAND ou SURRENDER

        if choix == 1: # Hit = pioche d'une carte et vérification d'un BUST
            print("----------------------------------\n")
            print("Tu as décidé de HIT.\n")
            joueur.donner_carte(monJeu.tirer_carte())
            joueur.calculer_points()
            print("----------------------------------\n")
            print(joueur)

            if joueur.points >21:
                print(dealer)
                score(dealer.points,joueur.points,mise)
                stop = True
                rejouer()


        elif choix == 2 : # Stand = pioche du Dealer + vérification d'un BUST + calcul des scores et résultat

            print("----------------------------------\n")
            print("Tu as décidé de STAND.\n")

            dealer.calculer_points()

            while dealer.points < 17:
                print("----------------------------------\n")
                print(dealer.donner_carte(monJeu.tirer_carte()))
                dealer.calculer_points()

            print("----------------------------------\n")
            print(joueur)
            print(dealer)
            score(dealer.points,joueur.points,mise)
            stop = True
            rejouer()


        else :
            print("----------------------------------\n")
            print("Tu as décider de SURRENDER ! Aurevoir !\n")
            stop = True

print("----------------------------------\n")
print ("Bienvenue au Casino Pas D'Bol !\n")

dealer = Dealer("Dealer", 1000000000)

nom_du_joueur = str(input("Quel est ton nom ?\n "))
joueur = Joueur(nom_du_joueur, 500)
print("Eh bien " + nom_du_joueur + ", je serai ravi de faire une partie de BlackJack contre toi.\n")

monJeu = Jeu_De_Cartes(54)
monJeu.melanger_paquet()

blackjack_jeu()