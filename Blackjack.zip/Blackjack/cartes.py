# Créé par nsi, le 03/10/2023 en Python 3.7

class Cartes :

    def __init__(self, valeur, couleur) : # Initialisation + Vérification de la valeur et de la couleur
        self.valeur = valeur
        self.couleur = couleur
        self.figure = None

    def obtenir_valeur(self) : # Renvoie la valeur
        print (self.valeur)
        return self.valeur

    def obtenir_couleur(self) : # Renvoie la couleur
        print (self.couleur)
        return self.couleur

    def obtenir_figure(self) : # Renvoie la figure
        print (self.figure)
        return self.figure

    def atribuer_valeur(self, valeur) : # Attribue une valeur (True) ou ne fais rien (False)
        if valeur >= 2 and valeur <= 14 :
            self.valeur = valeur
            return True
        return False

    def atribuer_couleur(self, couleur) : # Change la couleur (True) ou ne fais rien (False)
        if couleur == "Carreau" or couleur == "Pique" or couleur == "Trèfle" or couleur == "Coeur" :
            self.couleur = couleur
            return True
        return False

    def _atribuer_figure(self) : # Attribue une figure (True) ou ne fais rien (False)
        fig = ["Valet","Dame","Roi","As"]
        if self.valeur >= 11 :
            self.figure = fig[self.valeur-11]

    def __repr__(self) : # Change la façon de représenter une carte
        if self.figure == None :
            return str(self.valeur) + " de " + self.couleur
        else :
            return self.figure + " de " + self.couleur


