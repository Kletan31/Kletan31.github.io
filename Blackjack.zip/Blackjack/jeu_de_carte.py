# Créé par nsi, le 03/10/2023 en Python 3.7

from random import shuffle
from cartes import *

class Jeu_De_Cartes :

    def _creer_paquet(self, Nb_Cartes) : # Crée un paquet de 32 ou 54 cartes

        jeu = []

        if Nb_Cartes == 32 :
            for i in ["Carreau","Pique", "Trèfle", "Coeur"] :
                for j in range (7,15) :
                    carte = Cartes(j,i)
                    carte._atribuer_figure()
                    jeu.append(carte)
            return jeu

        else :
            for i in ["Carreau","Pique", "Trèfle", "Coeur"] :
                for j in range (2,15) :
                    carte = Cartes(j,i)
                    carte._atribuer_figure()
                    jeu.append(carte)
            return jeu

    def __init__ (self, Nb_Cartes) : # Initialisation + Vérification du nombre de cartes
        assert Nb_Cartes == 32 or Nb_Cartes == 54
        self.nb_cartes = Nb_Cartes
        self.JeuDeCartes = self._creer_paquet(Nb_Cartes)

    def obtenir_nb_cartes(self) : # Renvoie le nombre de cartes (32 ou 54)
        print(self.nb_cartes)

    def obtenir_jeu_de_cartes(self) : # Renvoie le jeu de cartes
        print(self.JeuDeCartes)

    def melanger_paquet(self) : # Mélange le paquet (ne le renvoie pas)
        self.JeudeCartes = shuffle(self.JeuDeCartes)

    def reinitialiser_paquet(self) : # Recrée un nouveau paquet (non mélangé)
        self.JeuDeCartes = self._creer_paquet(self.nb_cartes)

    def tirer_carte(self) : # Enlève la première carte et la renvoie
        return self.JeuDeCartes.pop(0)

