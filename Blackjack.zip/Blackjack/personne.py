# Créé par nsi, le 03/10/2023 en Python 3.7

from cartes import *
from jeu_de_carte import *
from random import shuffle

class Joueur :
    def __init__ (self, nom, jetons) : # Initialisation d'un joueur
        self.nom = nom
        self.jetons = jetons
        self.points = 0
        self.main = []

    def reinitialiser_joueur(self) : # Remet les points à 0 et la main devient vide
        self.points = 0
        self.main = []

    def obtenir_points(self) : # Renvoie les points
        print(self.points)
        return self.points

    def obtenir_nom(self) : # Renvoie le nom
        print(self.nom)
        return self.nom

    def afficher_main (self) : # Affiche la main
        print(self.main)

    def donner_carte(self, carte) : # Ajoute une carte à la main et l'annonce
        self.main.append(carte)
        print( "Vous avez pioché " + str(carte))

    def __as_a_la_fin(self) : # Met les as à début de la main
        aces = []
        other = []
        for e in self.main :
            if e.figure == "As" :
                aces.append(e)
            else :
                other.append(e)
        self.main = other + aces

    def __repr__(self) : # Change la représentation d'un joueur
        return "Le joueur " + self.nom + " a la main suivante : " + str(self.main) + " et possède " + str(self.points) + " point(s) ! Il détient actuellement " + str(self.jetons) + "jetons !\n"

    def calculer_points(self) : # Calcule les points d'un joueur
        self.points = 0
        self.__as_a_la_fin()

        for e in self.main :

            if e.valeur > 9 and e.valeur <= 13 :
                self.points += 10

            elif e.valeur <= 9 :
                self.points += e.valeur

            elif e.valeur == 14 :
                if self.points >= 11 :
                    self.points += 1
                else :
                    self.points += 11

        return self.points

    def miser(self, mise) :
        if self.jetons > mise :
            print("Le joueur " + self.nom + " a parié " + str(mise) + " jetons !\n")
            self.jetons -= mise
            return True
        elif self.jetons == mise :
            print("Le joueur " + self.nom + " a parié ses derniers jetons !!!\n")
            self.jetons -= mise
            return True
        elif self.jetons < mise :
            print("Le joueur " + self.nom + " ne peux pas parier autant de jetons...\n")
            return False


